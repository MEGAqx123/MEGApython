from setuptools import setup, find_packages

setup(
    name='MEGApython',          # Name of your package
    version='0.1',              # Version of the package
    description='start for turtle',  # Short description
    author='MEGAqx123',         # Your name
    author_email='MEGAqx123@gmail.com',  # Your email
    url='https://github.com/yourusername/MEGApython',  # URL to the project (if hosted on GitHub)
    packages=find_packages(),   # Automatically find packages in the current directory
    classifiers=[  # Optional: classifiers to help others discover your package
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    install_requires=[  # Add any dependencies here
        'turtle',
        'os',
    ],
)
