MEGApython
start for os and turtle
