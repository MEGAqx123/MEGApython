names = []
values = []
def get(name:str):
    for i in range(0,len(names)):
        if names[i] == name :
            val = i
    return(values[val])
def var(name:str,value):
    if len(str(name)) >= 3 and len(str(value)) >= 3:
         VarName = ""
         for i in range(0,len(names)):
             if names[i] == name :
                 values[i] = value
         if not name in names:
             names.append(name)
             values.append(value)

var("name",123)
print(f'value:{get("name")}')
        
      





