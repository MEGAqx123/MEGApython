import turtle
t = turtle.Pen()

# Convert RGB to Hexadecimal
def rgb_to_hex(r, g, b):
    """Converts an RGB color to hexadecimal."""
    return f"#{r:02x}{g:02x}{b:02x}"

# Basic Colors
black = rgb_to_hex(0, 0, 0)
white = rgb_to_hex(255, 255, 255)
red = rgb_to_hex(255, 0, 0)
green = rgb_to_hex(0, 255, 0)
blue = rgb_to_hex(0, 0, 255)
yellow = rgb_to_hex(255, 255, 0)
cyan = rgb_to_hex(0, 255, 255)
magenta = rgb_to_hex(255, 0, 255)
gray = rgb_to_hex(128, 128, 128)
light_gray = rgb_to_hex(211, 211, 211)
dark_gray = rgb_to_hex(169, 169, 169)

# Shades of Pink
pink = rgb_to_hex(255, 192, 203)
hot_pink = rgb_to_hex(255, 105, 180)
deep_pink = rgb_to_hex(255, 20, 147)
pale_violet_red = rgb_to_hex(219, 112, 147)
fuchsia = rgb_to_hex(255, 0, 255)
blush = rgb_to_hex(222, 93, 131)
light_pink = rgb_to_hex(255, 182, 193)
pink_salmon = rgb_to_hex(255, 145, 164)

# Shades of Purple
purple = rgb_to_hex(128, 0, 128)
lavender = rgb_to_hex(230, 230, 250)
orchid = rgb_to_hex(218, 112, 214)
violet = rgb_to_hex(238, 130, 238)
plum = rgb_to_hex(221, 160, 221)
indigo = rgb_to_hex(75, 0, 130)
amethyst = rgb_to_hex(153, 102, 204)
wisteria = rgb_to_hex(201, 160, 220)
mauve = rgb_to_hex(224, 176, 255)
lilac = rgb_to_hex(200, 162, 200)
periwinkle = rgb_to_hex(204, 204, 255)
purple_heart = rgb_to_hex(105, 53, 156)

# Shades of Red
crimson = rgb_to_hex(220, 20, 60)
firebrick = rgb_to_hex(178, 34, 34)
dark_red = rgb_to_hex(139, 0, 0)
tomato = rgb_to_hex(255, 99, 71)
salmon = rgb_to_hex(250, 128, 114)
light_coral = rgb_to_hex(240, 128, 128)
scarlet = rgb_to_hex(255, 36, 0)
ruby = rgb_to_hex(224, 17, 95)
cherry = rgb_to_hex(222, 49, 99)
rose = rgb_to_hex(255, 0, 127)
blood_red = rgb_to_hex(130, 0, 0)
brick_red = rgb_to_hex(203, 65, 84)
raspberry = rgb_to_hex(227, 11, 92)

# Shades of Blue
navy_blue = rgb_to_hex(0, 0, 128)
royal_blue = rgb_to_hex(65, 105, 225)
medium_blue = rgb_to_hex(0, 0, 205)
dodger_blue = rgb_to_hex(30, 144, 255)
sky_blue = rgb_to_hex(135, 206, 235)
light_blue = rgb_to_hex(173, 216, 230)
deep_sky_blue = rgb_to_hex(0, 191, 255)
azure = rgb_to_hex(0, 127, 255)
cerulean = rgb_to_hex(42, 82, 190)
midnight_blue = rgb_to_hex(25, 25, 112)
electric_blue = rgb_to_hex(44, 117, 255)
steel_blue = rgb_to_hex(70, 130, 180)
deep_sky_blue = rgb_to_hex(0, 191, 255)
light_sky_blue = rgb_to_hex(135, 206, 250)
powder_blue = rgb_to_hex(176, 224, 230)
aqua_marine = rgb_to_hex(127, 255, 212)
light_aqua = rgb_to_hex(190, 255, 255)
cobalt_blue = rgb_to_hex(0, 71, 171)
turquoise = rgb_to_hex(64, 224, 208)

# Function to draw a square
def a_square(x:int, y:int, size:int, pensize:int, color:str, faces:int):
    t.penup()
    t.goto(x, y)
    t.pensize(pensize)
    t.color(color)
    t.setheading(90)  # Correct way to set the heading upwards
    t.pendown()

    # Loop to draw a polygon with the specified number of faces (sides)
    for i in range(faces):
        t.forward(size)
        t.right(360 / faces)  # Rotate by the angle needed to complete the shape

    t.setheading(0)  # Optionally reset the heading to point right (or any desired angle)

# Function to draw a circle
def a_circle(x:int, y:int, size:int, pensize:int,color:str):
    t.penup()
    t.goto(x, y - size)  # Adjust starting position to place the circle correctly
    t.pensize(pensize)
    t.color(color)
    t.setheading(0)  # Make sure the turtle is facing right before starting the circle
    t.pendown()
    t.circle(size)

def speed(speed):
    t.speed(speed)

# Main execution to test the shapes
def main():
    # Set up the turtle window
    t.setup(500, 500)
    t.speed(5)
    turtle.done()

if __name__ == "__main__":
    main()
