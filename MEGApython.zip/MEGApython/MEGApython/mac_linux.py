import os
print('Note: For macOS and Linux, you may need to provide the sudo password, or you can run the script as a user with appropriate privileges to shut down/restart the system.')
def shutdown():
     os.system("sudo shutdown -h now")
def restart():
     os.system("sudo shutdown -r now")
