import os
def restart():
     os.system("shutdown /r /t 0")
def shutdown():
     os.system("shutdown /s /f /t 0")